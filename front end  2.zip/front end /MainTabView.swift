import SwiftUI

struct MainTabView: View {
    @EnvironmentObject var store: ExpenseStore

    var body: some View {
        TabView {
            DashboardView()
                .tabItem {
                    Label("Dashboard", systemImage: "house.fill")
                }

            ExpenseListView()
                .tabItem {
                    Label("Expenses", systemImage: "list.bullet")
                }

            AddExpenseView()
                .tabItem {
                    Label("Add", systemImage: "plus.circle.fill")
                }
        }
    }
}

#Preview {
    MainTabView().environmentObject(ExpenseStore.sampleStore())
}
