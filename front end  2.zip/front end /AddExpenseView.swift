import SwiftUI

struct AddExpenseView: View {
    @EnvironmentObject var store: ExpenseStore
    @State private var title = ""
    @State private var amount = ""
    @State private var category = "Food"
    @State private var date = Date()
    @State private var note = ""
    @State private var showAlert = false

    let categories = ["Food", "Transport", "Shopping", "Subscriptions", "Other"]

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Details")) {
                    TextField("Title", text: $title)
                    TextField("Amount", text: $amount)
                        .keyboardType(.decimalPad)
                    Picker("Category", selection: $category) {
                        ForEach(categories, id: \.\self) { cat in
                            Text(cat)
                        }
                    }
                    DatePicker("Date", selection: $date, displayedComponents: .date)
                    TextField("Note (optional)", text: $note)
                }

                Section {
                    Button(action: save) {
                        Text("Save Expense")
                            .frame(maxWidth: .infinity, alignment: .center)
                    }
                }
            }
            .navigationTitle("Add Expense")
            .alert("Invalid amount", isPresented: $showAlert) {
                Button("OK", role: .cancel) {}
            }
        }
    }

    func save() {
        guard let amt = Double(amount) else {
            showAlert = true
            return
        }
        let expense = Expense(title: title.isEmpty ? "No title" : title,
                              amount: amt,
                              category: category,
                              date: date,
                              note: note.isEmpty ? nil : note)
        store.add(expense)
        // Reset form
        title = ""
        amount = ""
        category = "Food"
        date = Date()
        note = ""
    }
}

#Preview {
    AddExpenseView().environmentObject(ExpenseStore.sampleStore())
}
