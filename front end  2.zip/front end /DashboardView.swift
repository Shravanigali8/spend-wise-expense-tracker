//
//  DashboardView.swift
//  SpendWise
//
//  Created by [Your Name] on [Date].
//  Description: Displays the Spend Wise project dashboard with progress updates.
//

import SwiftUI

struct DashboardView: View {
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    
                    SectionView(title: "Project Title") {
                        Text("Spend Wise – Personal Expense Tracker in SwiftUI & Core Data")
                    }
                    
                    SectionView(title: "Current Status") {
                        HStack {
                            Text("On Track")
                                .font(.subheadline)
                                .padding(6)
                                .background(Color.green.opacity(0.2))
                                .cornerRadius(8)
                                .foregroundColor(.green)
                            Spacer()
                        }
                        Text("Core features and UI have been implemented. Testing and performance improvements are ongoing.")
                            .padding(.top, 4)
                        BulletList(items: [
                            "Expense creation, editing, and deletion completed",
                            "Category-based filtering and sorting implemented",
                            "Dashboard and charts integrated using SwiftUI Charts",
                            "Core Data model finalized"
                        ])
                    }
                    
                    SectionView(title: "Pending Tasks") {
                        NumberedList(items: [
                            "Add export/share expense report feature",
                            "Integrate dark mode optimizations",
                            "Add daily/weekly/monthly spending summaries",
                            "Implement budget tracking alerts",
                            "Conduct final UI testing and App Store readiness checks"
                        ])
                    }
                    
                    SectionView(title: "Challenges Faced") {
                        BulletList(items: [
                            "Handling Core Data sync and state updates efficiently",
                            "Managing performance for large data sets",
                            "Chart data refresh timing issues in SwiftUI",
                            "Design consistency across device screen sizes"
                        ])
                    }
                }
                .padding()
            }
            .navigationTitle("Spend Wise Dashboard")
        }
    }
}

// MARK: - Section View
struct SectionView<Content: View>: View {
    var title: String
    var content: Content
    init(title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.title3)
                .fontWeight(.semibold)
                .foregroundColor(.blue)
            content
        }
        .padding()
        .background(Color(UIColor.secondarySystemBackground))
        .cornerRadius(12)
        .shadow(color: .gray.opacity(0.15), radius: 5, x: 0, y: 2)
    }
}

// MARK: - Bullet List
struct BulletList: View {
    var items: [String]
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(items, id: \.\self) { item in
                HStack(alignment: .top) {
                    Text("•")
                    Text(item)
                }
            }
        }
    }
}

// MARK: - Numbered List
struct NumberedList: View {
    var items: [String]
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(items.indices, id: \.\self) { i in
                HStack(alignment: .top) {
                    Text("\(i + 1).")
                    Text(items[i])
                }
            }
        }
    }
}

// MARK: - Preview
#Preview {
    DashboardView()
}
