import SwiftUI

struct ExpenseListView: View {
    @EnvironmentObject var store: ExpenseStore

    var body: some View {
        NavigationView {
            List {
                ForEach(store.expenses) { expense in
                    ExpenseRow(expense: expense)
                }
                .onDelete(perform: store.delete)
            }
            .navigationTitle("Expenses")
            .toolbar {
                EditButton()
            }
        }
    }
}

struct ExpenseRow: View {
    var expense: Expense

    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(expense.title)
                    .font(.headline)
                Text(expense.category)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Spacer()
            VStack(alignment: .trailing) {
                Text(String(format: "$%.2f", expense.amount))
                    .bold()
                Text(dateString(expense.date))
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 8)
    }

    func dateString(_ date: Date) -> String {
        let df = DateFormatter()
        df.dateStyle = .short
        return df.string(from: date)
    }
}

#Preview {
    ExpenseListView().environmentObject(ExpenseStore.sampleStore())
}
